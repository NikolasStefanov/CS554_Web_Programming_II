const users = require('./users');
const blogs = require('./blogs');

module.exports = {
    users: users,
    blogs: blogs
};